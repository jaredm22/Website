from enum import Enum

class Teams(Enum):
    ATLANTA_BRAVES = "Atlanta Braves"
    MIAMI_MARLINS = "Miami Marlins"
    New York Mets
    Philadelphia Phillies
    Washington Nationals

    Chicago Cubs
    Cincinnati Reds
    Milwaukee Brewers
    Pittsburgh Pirates
    St. Louis Cardinals

    Arizona Diamondbacks
    Colorado Rockies
    Los Angeles Dodgers
    San Diego Padres
    San Francisco Giants
    American League

    Baltimore Orioles
    Boston Red Sox
    New York Yankees
    Tampa Bay Rays
    Toronto Blue Jays

    Chicago White Sox
    Cleveland Indians
    Detroit Tigers
    Kansas City Royals
    Minnesota Twins

    Houston Astros
    Los Angeles Angels
    Oakland Athletics
    Seattle Mariners
    Texas Rangers"