class Team: 

    roster = []
    stats = []
    city = ""
    teamname = ""

    def __init__(self, cityname, name):
        city  = cityname
        teamname = name

class Player:

    stats = []
    firstname = ""
    lastname = ""

    def __init__(self, first, last):
        firstname = first
        lastname = last

class Game:

    stats = []
    firstname = ""
    lastname = ""

class Season:
    